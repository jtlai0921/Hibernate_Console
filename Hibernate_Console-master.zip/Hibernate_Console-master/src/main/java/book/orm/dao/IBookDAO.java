package book.orm.dao;


public interface IBookDAO extends IBaseDAO {
    void test();
}
